import React from "react";
import style from "../css/style.module.css";

const Footer = () => {
  return (
    <>
      <div className={style.footer}>@2020 TIP CALCULATOR</div>
    </>
  );
};

export default Footer;
